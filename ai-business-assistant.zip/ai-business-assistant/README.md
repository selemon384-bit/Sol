# AI Business Assistant

An AI-powered customer assistant that answers questions, searches a knowledge base, generates natural responses with Claude, and automatically saves leads to a database.

Built with **Python, FastAPI, SQLAlchemy, and the Anthropic API.**

## How it works

```
Customer message
      │
      ▼
┌─────────────────┐     ┌──────────────────────┐
│ Knowledge Base   │────▶│  Claude (Anthropic)  │
│ (TF-IDF search)  │     │  generates a natural │
└─────────────────┘     │  grounded response    │
                         └──────────┬───────────┘
                                    │
                     ┌──────────────┴──────────────┐
                     ▼                              ▼
             Conversation logged             Lead saved (if contact
             to SQLite                       info was provided)
```

1. A customer sends a message to `POST /chat`.
2. The knowledge base is searched using TF-IDF + cosine similarity to find the most relevant FAQ entry (if any).
3. Claude generates a natural-language reply, grounded in that FAQ entry when one is found, so it never invents facts, prices, or policies.
4. The exchange is logged to the database for history/analytics.
5. If the customer provided a name or email, a lead is saved automatically.

## Features

- 🔍 **Knowledge base search** — lightweight TF-IDF matching, no external search API needed
- 🤖 **AI-generated responses** — powered by Claude, grounded in real FAQ content
- 💾 **Lead capture** — automatically saves contact info + the question that brought them in
- 📊 **Conversation history** — every exchange is logged for later analysis
- 🌐 **REST API** — clean FastAPI endpoints, auto-generated docs at `/docs`
- 💬 **Demo chat widget** — a working frontend included, no setup needed to try it

## Tech stack

| Layer          | Technology              |
|----------------|--------------------------|
| API framework  | FastAPI                  |
| Database ORM   | SQLAlchemy               |
| Database       | SQLite (swap in Postgres/MySQL by changing one env var) |
| AI             | Anthropic Claude API     |
| Search         | scikit-learn (TF-IDF)    |
| Frontend       | Vanilla HTML/CSS/JS      |

## Project structure

```
ai-business-assistant/
├── app/
│   ├── main.py            # FastAPI app & routes
│   ├── database.py        # DB engine/session setup
│   ├── models.py          # SQLAlchemy models (Lead, Conversation)
│   ├── schemas.py         # Pydantic request/response schemas
│   ├── knowledge_base.py  # TF-IDF FAQ search
│   └── ai_service.py      # Claude API integration
├── knowledge_base/
│   └── faqs.json          # Sample FAQ data — edit this for your business
├── static/
│   └── index.html         # Demo chat widget
├── requirements.txt
├── .env.example
└── README.md
```

## Setup

**1. Clone and install dependencies**
```bash
git clone <your-repo-url>
cd ai-business-assistant
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

**2. Configure your API key**
```bash
cp .env.example .env
# then edit .env and add your ANTHROPIC_API_KEY
```
Get a key at [console.anthropic.com](https://console.anthropic.com).

**3. Run the server**
```bash
uvicorn app.main:app --reload
```

**4. Try it**
- Chat widget: [http://localhost:8000](http://localhost:8000)
- Interactive API docs: [http://localhost:8000/docs](http://localhost:8000/docs)

## API Reference

### `POST /chat`
Send a customer message and get an AI-generated response.

```json
// Request
{
  "session_id": "abc123",
  "message": "Do you offer a free trial?",
  "name": "Jane Doe",       // optional — saves a lead if provided
  "email": "jane@email.com" // optional
}

// Response
{
  "response": "Yes! Every plan includes a 14-day free trial, no credit card required.",
  "matched_topic": "product",
  "lead_saved": true
}
```

### `GET /leads`
Returns all captured leads, most recent first.

### `GET /health`
Simple health check for uptime monitoring.

## Customizing for your own business

- Edit `knowledge_base/faqs.json` with your real FAQs — no retraining needed, changes take effect on restart.
- Adjust `MATCH_THRESHOLD` in `app/knowledge_base.py` to control how strict the FAQ matching is.
- Edit `SYSTEM_PROMPT` in `app/ai_service.py` to change the assistant's tone and rules.

## Possible extensions

- Swap SQLite for Postgres for production use
- Add Telegram/Slack notifications when a new lead is saved (see the companion **n8n Business Automation System** project)
- Add authentication for the `/leads` endpoint
- Embed the widget as a script tag on an existing website

---

Part of a portfolio of AI & automation projects. See the [Automation Portfolio Showcase](#) for the full set.
