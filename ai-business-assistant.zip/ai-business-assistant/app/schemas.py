"""Pydantic schemas for request/response validation."""

from datetime import datetime
from typing import Optional
from pydantic import BaseModel, EmailStr


class ChatRequest(BaseModel):
    session_id: str
    message: str
    # Optional contact info - if provided, we save the person as a lead
    name: Optional[str] = None
    email: Optional[EmailStr] = None


class ChatResponse(BaseModel):
    response: str
    matched_topic: Optional[str] = None
    lead_saved: bool = False


class LeadOut(BaseModel):
    id: int
    name: Optional[str]
    email: Optional[str]
    original_question: str
    status: str
    created_at: datetime

    class Config:
        from_attributes = True
