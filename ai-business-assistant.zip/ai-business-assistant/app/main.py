"""
AI Business Assistant — main FastAPI application.

Flow:
  1. Customer sends a message via POST /chat
  2. We search the knowledge base for a relevant FAQ
  3. Claude generates a natural response, grounded in that FAQ if found
  4. The exchange is logged; if the customer gave contact info, a lead is saved
  5. Response is returned to the customer
"""

from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from sqlalchemy import desc
import os

from app.database import engine, Base, get_db
from app import models
from app.schemas import ChatRequest, ChatResponse, LeadOut
from app.knowledge_base import knowledge_base
from app.ai_service import generate_response

# Create tables on startup (fine for SQLite/demo use; use Alembic migrations in production)
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="AI Business Assistant",
    description="An AI-powered assistant that answers customer questions, "
    "searches a knowledge base, and captures leads automatically.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten this to your real frontend domain in production
    allow_methods=["*"],
    allow_headers=["*"],
)

STATIC_DIR = os.path.join(os.path.dirname(__file__), "..", "static")
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


@app.get("/")
def serve_widget():
    """Serve the demo chat widget."""
    return FileResponse(os.path.join(STATIC_DIR, "index.html"))


@app.post("/chat", response_model=ChatResponse)
def chat(request: ChatRequest, db: Session = Depends(get_db)):
    # 1. Search the knowledge base
    kb_match = knowledge_base.search(request.message)

    # 2. Generate the AI response
    ai_reply = generate_response(request.message, kb_match)

    # 3. Log the conversation
    conversation = models.Conversation(
        session_id=request.session_id,
        user_message=request.message,
        ai_response=ai_reply,
        matched_topic=kb_match["topic"] if kb_match else None,
    )
    db.add(conversation)

    # 4. Save as a lead if the customer gave contact info
    lead_saved = False
    if request.email or request.name:
        lead = models.Lead(
            name=request.name,
            email=request.email,
            original_question=request.message,
        )
        db.add(lead)
        lead_saved = True

    db.commit()

    return ChatResponse(
        response=ai_reply,
        matched_topic=kb_match["topic"] if kb_match else None,
        lead_saved=lead_saved,
    )


@app.get("/leads", response_model=list[LeadOut])
def list_leads(db: Session = Depends(get_db)):
    """View all captured leads, most recent first."""
    return db.query(models.Lead).order_by(desc(models.Lead.created_at)).all()


@app.get("/health")
def health_check():
    return {"status": "ok"}
