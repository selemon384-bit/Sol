"""Database models."""

from datetime import datetime
from sqlalchemy import Column, Integer, String, Text, DateTime
from app.database import Base


class Lead(Base):
    """A potential customer captured from a conversation."""

    __tablename__ = "leads"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(120), nullable=True)
    email = Column(String(120), nullable=True, index=True)
    original_question = Column(Text, nullable=False)
    status = Column(String(30), default="new")  # new, contacted, converted
    created_at = Column(DateTime, default=datetime.utcnow)


class Conversation(Base):
    """A single question/answer exchange, for history and analytics."""

    __tablename__ = "conversations"

    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(String(64), index=True)
    user_message = Column(Text, nullable=False)
    ai_response = Column(Text, nullable=False)
    matched_topic = Column(String(60), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
