"""
Knowledge base search.

Loads FAQ entries from a JSON file and finds the most relevant one for a
given customer question using TF-IDF + cosine similarity. This keeps the
search fast, dependency-light, and fully explainable (no external API
calls needed just to search).
"""

import json
import os
from typing import Optional, TypedDict

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

KB_PATH = os.path.join(os.path.dirname(__file__), "..", "knowledge_base", "faqs.json")

# Below this similarity score, we treat the knowledge base as "no good match"
# and let the AI answer more generally instead of forcing a bad FAQ match.
MATCH_THRESHOLD = 0.15


class KBMatch(TypedDict):
    topic: str
    question: str
    answer: str
    score: float


class KnowledgeBase:
    def __init__(self, path: str = KB_PATH):
        with open(path, "r", encoding="utf-8") as f:
            self.entries = json.load(f)

        corpus = [entry["question"] for entry in self.entries]
        self.vectorizer = TfidfVectorizer(stop_words="english")
        self.matrix = self.vectorizer.fit_transform(corpus)

    def search(self, query: str) -> Optional[KBMatch]:
        """Return the best-matching FAQ entry, or None if nothing scores high enough."""
        if not query.strip():
            return None

        query_vec = self.vectorizer.transform([query])
        scores = cosine_similarity(query_vec, self.matrix)[0]

        best_idx = scores.argmax()
        best_score = float(scores[best_idx])

        if best_score < MATCH_THRESHOLD:
            return None

        entry = self.entries[best_idx]
        return {
            "topic": entry["topic"],
            "question": entry["question"],
            "answer": entry["answer"],
            "score": best_score,
        }


# Singleton instance used across the app
knowledge_base = KnowledgeBase()
