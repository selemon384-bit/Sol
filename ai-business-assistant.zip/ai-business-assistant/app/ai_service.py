"""
AI response generation using the Anthropic API.

The knowledge base gives us a factual anchor (if a match is found); Claude
turns that into a natural, on-brand reply and handles cases where no FAQ
matches at all.
"""

import os
from typing import Optional
from anthropic import Anthropic
from dotenv import load_dotenv

load_dotenv()

client = Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))
MODEL = os.getenv("CLAUDE_MODEL", "claude-sonnet-4-6")

SYSTEM_PROMPT = """You are a friendly, professional AI assistant for a business.
Answer customer questions clearly and concisely (2-4 sentences).
If knowledge base context is provided, base your answer on it and do not
contradict it. If no context is provided, answer helpfully in general terms
and invite the customer to leave their email for a follow-up from the team.
Never make up specific prices, policies, or dates that weren't given to you."""


def generate_response(user_message: str, kb_context: Optional[dict]) -> str:
    if kb_context:
        context_block = (
            f"Relevant knowledge base entry:\n"
            f"Q: {kb_context['question']}\n"
            f"A: {kb_context['answer']}\n"
        )
    else:
        context_block = "No matching knowledge base entry was found for this question."

    user_prompt = f"{context_block}\n\nCustomer question: {user_message}"

    message = client.messages.create(
        model=MODEL,
        max_tokens=300,
        system=SYSTEM_PROMPT,
        messages=[{"role": "user", "content": user_prompt}],
    )

    return message.content[0].text
